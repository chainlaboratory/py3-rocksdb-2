import os
import sys
import shutil
import gc
import unittest
import rocksdb
from itertools import takewhile
import struct
import tempfile
from rocksdb.merge_operators import UintAddOperator, StringAppendOperator

def int_to_bytes(ob):
    return str(ob).encode('ascii')

class TestHelper(unittest.TestCase):

    def setUp(self):
        self.db_loc = tempfile.mkdtemp()
        self.addCleanup(self._close_db)

    def _close_db(self):
        if hasattr(self, 'db'):
            del self.db
        gc.collect()
        if os.path.exists(self.db_loc):
            shutil.rmtree(self.db_loc)


class TestDB(TestHelper):
    def setUp(self):
        TestHelper.setUp(self)
        opts = rocksdb.Options(create_if_missing=True)
        self.db = rocksdb.DB(os.path.join(self.db_loc, "test"), opts)

    def test_options_used_twice(self):
        if sys.version_info[0] == 3:
            assertRaisesRegex = self.assertRaisesRegex
        else:
            assertRaisesRegex = self.assertRaisesRegexp
        expected = "Options object is already used by another DB"
        with assertRaisesRegex(Exception, expected):
            rocksdb.DB(os.path.join(self.db_loc, "test2"), self.db.options)

    def test_unicode_path(self):
        name = os.path.join(self.db_loc, b'M\xc3\xbcnchen'.decode('utf8'))
        rocksdb.DB(name, rocksdb.Options(create_if_missing=True))
        self.addCleanup(shutil.rmtree, name)
        self.assertTrue(os.path.isdir(name))

    def test_get_none(self):
        self.assertIsNone(self.db.get(b'xxx'))

    def test_put_get(self):
        self.db.put(b"a", b"b")
        self.assertEqual(b"b", self.db.get(b"a"))

    def test_multi_get(self):
        self.db.put(b"a", b"1")
        self.db.put(b"b", b"2")
        self.db.put(b"c", b"3")

        ret = self.db.multi_get([b'a', b'b', b'c'])
        ref = {b'a': b'1', b'c': b'3', b'b': b'2'}
        self.assertEqual(ref, ret)

    def test_delete(self):
        self.db.put(b"a", b"b")
        self.assertEqual(b"b", self.db.get(b"a"))
        self.db.delete(b"a")
        self.assertIsNone(self.db.get(b"a"))

    def test_write_batch(self):
        batch = rocksdb.WriteBatch()
        batch.put(b"key", b"v1")
        batch.delete(b"key")
        batch.put(b"key", b"v2")
        batch.put(b"key", b"v3")
        batch.put(b"a", b"b")

        self.db.write(batch)
        ref = {b'a': b'b', b'key': b'v3'}
        ret = self.db.multi_get([b'key', b'a'])
        self.assertEqual(ref, ret)

    def test_write_batch_iter(self):
        batch = rocksdb.WriteBatch()
        self.assertEqual([], list(batch))

        batch.put(b"key1", b"v1")
        batch.put(b"key2", b"v2")
        batch.put(b"key3", b"v3")
        batch.delete(b'a')
        batch.delete(b'key1')
        batch.merge(b'xxx', b'value')

        it = iter(batch)
        del batch
        ref = [
            ('Put', b'key1', b'v1'),
            ('Put', b'key2', b'v2'),
            ('Put', b'key3', b'v3'),
            ('Delete', b'a', b''),
            ('Delete', b'key1', b''),
            ('Merge', b'xxx', b'value')
        ]
        self.assertEqual(ref, list(it))


    def test_key_may_exists(self):
        self.db.put(b"a", b'1')

        self.assertEqual((False, None), self.db.key_may_exist(b"x"))
        self.assertEqual((False, None), self.db.key_may_exist(b'x', True))
        self.assertEqual((True, None), self.db.key_may_exist(b'a'))
        self.assertEqual((True, b'1'), self.db.key_may_exist(b'a', True))

    def test_seek_for_prev(self):
        self.db.put(b'a1', b'a1_value')
        self.db.put(b'a3', b'a3_value')
        self.db.put(b'b1', b'b1_value')
        self.db.put(b'b2', b'b2_value')
        self.db.put(b'c2', b'c2_value')
        self.db.put(b'c4', b'c4_value')

        self.assertEqual(self.db.get(b'a1'), b'a1_value')

        it = self.db.iterkeys()

        it.seek(b'a1')
        self.assertEqual(it.get(), b'a1')
        it.seek(b'a3')
        self.assertEqual(it.get(), b'a3')
        it.seek_for_prev(b'c4')
        self.assertEqual(it.get(), b'c4')
        it.seek_for_prev(b'c3')
        self.assertEqual(it.get(), b'c2')

        it = self.db.itervalues()
        it.seek(b'a1')
        self.assertEqual(it.get(), b'a1_value')
        it.seek(b'a3')
        self.assertEqual(it.get(), b'a3_value')
        it.seek_for_prev(b'c4')
        self.assertEqual(it.get(), b'c4_value')
        it.seek_for_prev(b'c3')
        self.assertEqual(it.get(), b'c2_value')

        it = self.db.iteritems()
        it.seek(b'a1')
        self.assertEqual(it.get(), (b'a1', b'a1_value'))
        it.seek(b'a3')
        self.assertEqual(it.get(), (b'a3', b'a3_value'))
        it.seek_for_prev(b'c4')
        self.assertEqual(it.get(), (b'c4', b'c4_value'))
        it.seek_for_prev(b'c3')
        self.assertEqual(it.get(), (b'c2', b'c2_value'))

        reverse_it = reversed(it)
        it.seek_for_prev(b'c3')
        self.assertEqual(it.get(), (b'c2', b'c2_value'))


    def test_iter_keys(self):
        for x in range(300):
            self.db.put(int_to_bytes(x), int_to_bytes(x))

        it = self.db.iterkeys()

        self.assertEqual([], list(it))

        it.seek_to_last()
        self.assertEqual([b'99'], list(it))

        ref = sorted([int_to_bytes(x) for x in range(300)])
        it.seek_to_first()
        self.assertEqual(ref, list(it))

        it.seek(b'90')
        ref = [
            b'90',
            b'91',
            b'92',
            b'93',
            b'94',
            b'95',
            b'96',
            b'97',
            b'98',
            b'99'
        ]
        self.assertEqual(ref, list(it))

    def test_iter_values(self):
        for x in range(300):
            self.db.put(int_to_bytes(x), int_to_bytes(x * 1000))

        it = self.db.itervalues()

        self.assertEqual([], list(it))

        it.seek_to_last()
        self.assertEqual([b'99000'], list(it))

        ref = sorted([int_to_bytes(x) for x in range(300)])
        ref = [int_to_bytes(int(x) * 1000) for x in ref]
        it.seek_to_first()
        self.assertEqual(ref, list(it))

        it.seek(b'90')
        ref = [int_to_bytes(x * 1000) for x in range(90, 100)]
        self.assertEqual(ref, list(it))

    def test_iter_items(self):
        for x in range(300):
            self.db.put(int_to_bytes(x), int_to_bytes(x * 1000))

        it = self.db.iteritems()

        self.assertEqual([], list(it))

        it.seek_to_last()
        self.assertEqual([(b'99', b'99000')], list(it))

        ref = sorted([int_to_bytes(x) for x in range(300)])
        ref = [(x, int_to_bytes(int(x) * 1000)) for x in ref]
        it.seek_to_first()
        self.assertEqual(ref, list(it))

        it.seek(b'90')
        ref = [(int_to_bytes(x), int_to_bytes(x * 1000)) for x in range(90, 100)]
        self.assertEqual(ref, list(it))

    def test_reverse_iter(self):
        for x in range(100):
            self.db.put(int_to_bytes(x), int_to_bytes(x * 1000))

        it = self.db.iteritems()
        it.seek_to_last()

        ref = reversed(sorted([int_to_bytes(x) for x in range(100)]))
        ref = [(x, int_to_bytes(int(x) * 1000)) for x in ref]

        self.assertEqual(ref, list(reversed(it)))

    def test_snapshot(self):
        self.db.put(b"a", b"1")
        self.db.put(b"b", b"2")

        snapshot = self.db.snapshot()
        self.db.put(b"a", b"2")
        self.db.delete(b"b")

        it = self.db.iteritems()
        it.seek_to_first()
        self.assertEqual({b'a': b'2'}, dict(it))

        it = self.db.iteritems(snapshot=snapshot)
        it.seek_to_first()
        self.assertEqual({b'a': b'1', b'b': b'2'}, dict(it))

    def test_get_property(self):
        for x in range(300):
            x = int_to_bytes(x)
            self.db.put(x, x)

        self.assertIsNotNone(self.db.get_property(b'rocksdb.stats'))
        self.assertIsNotNone(self.db.get_property(b'rocksdb.sstables'))
        self.assertIsNotNone(self.db.get_property(b'rocksdb.num-files-at-level0'))
        self.assertIsNone(self.db.get_property(b'does not exsits'))

    def test_compact_range(self):
        for x in range(10000):
            x = int_to_bytes(x)
            self.db.put(x, x)

        self.db.compact_range()

    def test_write_ignore_missing_column_families(self):
        self.db.put(b"a", b"1", ignore_missing_column_families=True)

    def test_write_no_slowdown(self):
        self.db.put(b"a", b"1", no_slowdown=True)

    def test_write_low_pri(self):
        self.db.put(b"a", b"1", low_pri=True)

    # --- close() lifecycle ------------------------------------------------

    def test_close_reopen(self):
        # Data written before an explicit close() must survive reopening a
        # fresh handle at the same path.
        path = os.path.join(self.db_loc, "test")
        self.db.put(b'persist', b'value')
        self.db.close()

        reopened = rocksdb.DB(path, rocksdb.Options(create_if_missing=False))
        try:
            self.assertEqual(b'value', reopened.get(b'persist'))
        finally:
            reopened.close()
            del reopened
            gc.collect()

    def test_double_close(self):
        # close() is idempotent -- the second call is a guarded no-op and must
        # not raise or crash. (For TransactionDB, run via the inherited suite,
        # this also guards against close() failing to reset the db pointer.)
        self.db.close()
        self.db.close()

    def test_use_after_close_raises(self):
        # Operating on a closed DB must raise cleanly rather than dereferencing
        # a NULL handle and segfaulting.
        self.db.close()
        self.assertRaises(RuntimeError, self.db.put, b'k', b'v')
        self.assertRaises(RuntimeError, self.db.get, b'k')

    # --- live files / column-family metadata ------------------------------

    def test_live_files_metadata(self):
        for x in range(10000):
            x = int_to_bytes(x)
            self.db.put(x, x)
        # No flush() is exposed; compact_range() forces a flush + compaction so
        # the data lands in at least one live SST file.
        self.db.compact_range()

        meta = self.db.get_live_files_metadata()
        self.assertIsInstance(meta, list)
        self.assertGreaterEqual(len(meta), 1)

        entry = meta[0]
        self.assertEqual(
            {'name', 'level', 'size', 'smallestkey', 'largestkey',
             'smallest_seqno', 'largest_seqno'},
            set(entry.keys()))
        self.assertIsInstance(entry['name'], str)
        self.assertIsInstance(entry['level'], int)
        self.assertIsInstance(entry['size'], int)
        self.assertGreater(entry['size'], 0)
        self.assertIsInstance(entry['smallestkey'], bytes)
        self.assertIsInstance(entry['largestkey'], bytes)
        self.assertIsInstance(entry['smallest_seqno'], int)
        self.assertIsInstance(entry['largest_seqno'], int)

    def test_column_family_meta_data(self):
        for x in range(10000):
            x = int_to_bytes(x)
            self.db.put(x, x)
        self.db.compact_range()

        meta = self.db.get_column_family_meta_data()
        self.assertEqual({'size', 'file_count'}, set(meta.keys()))
        self.assertIsInstance(meta['size'], int)
        self.assertGreater(meta['size'], 0)
        self.assertIsInstance(meta['file_count'], int)
        self.assertGreaterEqual(meta['file_count'], 1)

    # --- negative / error paths -------------------------------------------

    def test_open_missing_db(self):
        missing = os.path.join(self.db_loc, "does_not_exist")
        # The concrete subclass (NotFound / RocksIOError) is RocksDB-version
        # dependent, so assert against the common base.
        self.assertRaises(
            rocksdb.Error,
            rocksdb.DB, missing, rocksdb.Options(create_if_missing=False))

    def test_open_error_if_exists(self):
        # Create-and-close a throwaway DB at a fresh path (so this is the
        # error_if_exists check, not a file-lock error from self.db), then
        # reopening it with error_if_exists=True must fail.
        path = os.path.join(self.db_loc, "exists_test")
        tmp = rocksdb.DB(path, rocksdb.Options(create_if_missing=True))
        tmp.close()
        del tmp
        gc.collect()

        self.assertRaises(
            rocksdb.Error,
            rocksdb.DB, path,
            rocksdb.Options(create_if_missing=True, error_if_exists=True))

    def test_put_non_bytes_key(self):
        self.assertRaises(TypeError, self.db.put, u'not-bytes', b'v')
        self.assertRaises(TypeError, self.db.put, 123, b'v')

    def test_put_non_bytes_value(self):
        self.assertRaises(TypeError, self.db.put, b'k', u'not-bytes')
        self.assertRaises(TypeError, self.db.put, b'k', 123)

    # --- read-only mode ----------------------------------------------------

    def test_read_only_open(self):
        path = os.path.join(self.db_loc, "test")
        self.db.put(b'k', b'v')
        self.db.close()

        ro = rocksdb.DB(
            path, rocksdb.Options(create_if_missing=False), read_only=True)
        try:
            self.assertEqual(b'v', ro.get(b'k'))
            self.assertRaises(rocksdb.NotSupported, ro.put, b'k2', b'v2')
        finally:
            ro.close()
            del ro
            gc.collect()

    # --- multi_get edge cases ---------------------------------------------

    def test_multi_get_missing_key(self):
        self.db.put(b'present', b'v')
        ret = self.db.multi_get([b'present', b'absent'])
        self.assertEqual({b'present': b'v', b'absent': None}, ret)

    def test_multi_get_as_list(self):
        self.db.put(b'a', b'va')
        self.db.put(b'b', b'vb')
        # as_dict=False returns a parallel list -- duplicates preserved, missing
        # keys mapped to None -- unlike the dict form which de-dups keys.
        ret = self.db.multi_get([b'a', b'b', b'a', b'missing'], as_dict=False)
        self.assertEqual([b'va', b'vb', b'va', None], ret)


class AssocCounter(rocksdb.interfaces.AssociativeMergeOperator):
    def merge(self, key, existing_value, value):
        if existing_value:
            return (True, int_to_bytes(int(existing_value) + int(value)))
        return (True, value)

    def name(self):
        return b'AssocCounter'


class TestUint64Merge(TestHelper):
    def setUp(self):
        TestHelper.setUp(self)
        opts = rocksdb.Options()
        opts.create_if_missing = True
        opts.merge_operator = UintAddOperator()
        self.db = rocksdb.DB(os.path.join(self.db_loc, 'test'), opts)

    def test_merge(self):
        self.db.put(b'a', struct.pack('Q', 5566))
        for x in range(1000):
            self.db.merge(b"a", struct.pack('Q', x))
        self.assertEqual(5566 + sum(range(1000)), struct.unpack('Q', self.db.get(b'a'))[0])


#  class TestPutMerge(TestHelper):
    #  def setUp(self):
        #  TestHelper.setUp(self)
        #  opts = rocksdb.Options()
        #  opts.create_if_missing = True
        #  opts.merge_operator = "put"
        #  self.db = rocksdb.DB(os.path.join(self.db_loc, 'test'), opts)

    #  def test_merge(self):
        #  self.db.put(b'a', b'ccc')
        #  self.db.merge(b'a', b'ddd')
        #  self.assertEqual(self.db.get(b'a'), 'ddd')

#  class TestPutV1Merge(TestHelper):
    #  def setUp(self):
        #  TestHelper.setUp(self)
        #  opts = rocksdb.Options()
        #  opts.create_if_missing = True
        #  opts.merge_operator = "put_v1"
        #  self.db = rocksdb.DB(os.path.join(self.db_loc, 'test'), opts)

    #  def test_merge(self):
        #  self.db.put(b'a', b'ccc')
        #  self.db.merge(b'a', b'ddd')
        #  self.assertEqual(self.db.get(b'a'), 'ddd')

class TestStringAppendOperatorMerge(TestHelper):
    def setUp(self):
        TestHelper.setUp(self)
        opts = rocksdb.Options()
        opts.create_if_missing = True
        opts.merge_operator = StringAppendOperator()
        self.db = rocksdb.DB(os.path.join(self.db_loc, 'test'), opts)

    # NOTE(sileht): Raise "Corruption: Error: Could not perform merge." on PY3
    #@unittest.skipIf(sys.version_info[0] == 3,
    #                 "Unexpected behavior on PY3")
    def test_merge(self):
        self.db.put(b'a', b'ccc')
        self.db.merge(b'a', b'ddd')
        self.assertEqual(self.db.get(b'a'), b'ccc,ddd')

#  class TestStringMaxOperatorMerge(TestHelper):
    #  def setUp(self):
        #  TestHelper.setUp(self)
        #  opts = rocksdb.Options()
        #  opts.create_if_missing = True
        #  opts.merge_operator = "max"
        #  self.db = rocksdb.DB(os.path.join(self.db_loc, 'test'), opts)

    #  def test_merge(self):
        #  self.db.put(b'a', int_to_bytes(55))
        #  self.db.merge(b'a', int_to_bytes(56))
        #  self.assertEqual(int(self.db.get(b'a')), 56)


class TestAssocMerge(TestHelper):
    def setUp(self):
        TestHelper.setUp(self)
        opts = rocksdb.Options()
        opts.create_if_missing = True
        opts.merge_operator = AssocCounter()
        self.db = rocksdb.DB(os.path.join(self.db_loc, 'test'), opts)

    def test_merge(self):
        for x in range(1000):
            self.db.merge(b"a", int_to_bytes(x))
        self.assertEqual(sum(range(1000)), int(self.db.get(b'a')))


class FullCounter(rocksdb.interfaces.MergeOperator):
    def name(self):
        return b'fullcounter'

    def full_merge(self, key, existing_value, operand_list):
        ret = sum([int(x) for x in operand_list])
        if existing_value:
            ret += int(existing_value)

        return (True, int_to_bytes(ret))

    def partial_merge(self, key, left, right):
        return (True, int_to_bytes(int(left) + int(right)))


class TestFullMerge(TestHelper):
    def setUp(self):
        TestHelper.setUp(self)
        opts = rocksdb.Options()
        opts.create_if_missing = True
        opts.merge_operator = FullCounter()
        self.db = rocksdb.DB(os.path.join(self.db_loc, 'test'), opts)

    def test_merge(self):
        for x in range(1000):
            self.db.merge(b"a", int_to_bytes(x))
        self.assertEqual(sum(range(1000)), int(self.db.get(b'a')))


class SimpleComparator(rocksdb.interfaces.Comparator):
    def name(self):
        return b'mycompare'

    def compare(self, a, b):
        a = int(a)
        b = int(b)
        if a < b:
            return -1
        if a == b:
            return 0
        if a > b:
            return 1


class TestComparator(TestHelper):
    def setUp(self):
        TestHelper.setUp(self)
        opts = rocksdb.Options()
        opts.create_if_missing = True
        opts.comparator = SimpleComparator()
        self.db = rocksdb.DB(os.path.join(self.db_loc, 'test'), opts)

    def test_compare(self):
        for x in range(1000):
            self.db.put(int_to_bytes(x), int_to_bytes(x))

        self.assertEqual(b'300', self.db.get(b'300'))


class RaisingComparator(rocksdb.interfaces.Comparator):
    def name(self):
        return b'raising'

    def compare(self, a, b):
        raise ValueError('boom in compare')


class TestRaisingCallback(TestHelper):
    # Regression guard for the Cython 3 `noexcept` migration: a Python
    # exception raised inside a C/C++ callback must surface as a Python-level
    # exception (with its message intact) instead of unwinding into C++ and
    # aborting the process.
    def test_raising_comparator_surfaces_python_exception(self):
        opts = rocksdb.Options(create_if_missing=True)
        opts.comparator = RaisingComparator()
        self.db = rocksdb.DB(os.path.join(self.db_loc, 'test'), opts)
        with self.assertRaises(Exception) as ctx:
            # Inserting keys forces key comparisons, which raise in Python.
            # If the process survives to raise here, noexcept worked.
            for x in range(100):
                self.db.put(int_to_bytes(x), b'v')
        self.assertIn('boom in compare', str(ctx.exception))


class TestBackup(TestHelper):
    # Validates the BackupEngine bindings against modern RocksDB
    # (rocksdb/utilities/backup_engine.h, BackupEngineOptions, IOStatus).
    def setUp(self):
        TestHelper.setUp(self)
        opts = rocksdb.Options(create_if_missing=True)
        self.db = rocksdb.DB(os.path.join(self.db_loc, 'test'), opts)

    def test_backup_and_restore(self):
        self.db.put(b'key', b'value')

        backup_dir = os.path.join(self.db_loc, 'backup')
        engine = rocksdb.BackupEngine(backup_dir)
        engine.create_backup(self.db, flush_before_backup=True)

        info = engine.get_backup_info()
        self.assertEqual(1, len(info))
        self.assertEqual(1, info[0]['backup_id'])

        # Close the original DB, then restore the backup into a fresh location.
        del self.db
        gc.collect()
        restore_dir = os.path.join(self.db_loc, 'restored')
        engine.restore_latest_backup(restore_dir, restore_dir)

        self.db = rocksdb.DB(restore_dir, rocksdb.Options(create_if_missing=False))
        self.assertEqual(b'value', self.db.get(b'key'))


class StaticPrefix(rocksdb.interfaces.SliceTransform):
    def name(self):
        return b'static'

    def transform(self, src):
        return (0, 5)

    def in_domain(self, src):
        return len(src) >= 5

    def in_range(self, dst):
        return len(dst) == 5

class TestPrefixExtractor(TestHelper):
    def setUp(self):
        TestHelper.setUp(self)
        opts = rocksdb.Options(create_if_missing=True)
        opts.prefix_extractor = StaticPrefix()
        self.db = rocksdb.DB(os.path.join(self.db_loc, 'test'), opts)

    def _fill_db(self):
        for x in range(3000):
            keyx = hex(x)[2:].zfill(5).encode('utf8') + b'.x'
            keyy = hex(x)[2:].zfill(5).encode('utf8') + b'.y'
            keyz = hex(x)[2:].zfill(5).encode('utf8') + b'.z'
            self.db.put(keyx, b'x')
            self.db.put(keyy, b'y')
            self.db.put(keyz, b'z')


    def test_prefix_iterkeys(self):
        self._fill_db()
        self.assertEqual(b'x', self.db.get(b'00001.x'))
        self.assertEqual(b'y', self.db.get(b'00001.y'))
        self.assertEqual(b'z', self.db.get(b'00001.z'))

        it = self.db.iterkeys()
        it.seek(b'00002')

        ref = [b'00002.x', b'00002.y', b'00002.z']
        ret = takewhile(lambda key: key.startswith(b'00002'), it)
        self.assertEqual(ref, list(ret))

    def test_prefix_iteritems(self):
        self._fill_db()

        it = self.db.iteritems()
        it.seek(b'00002')

        ref = {b'00002.z': b'z', b'00002.y': b'y', b'00002.x': b'x'}
        ret = takewhile(lambda item: item[0].startswith(b'00002'), it)
        self.assertEqual(ref, dict(ret))

class TestFixedPrefixExtractor(TestHelper):
    def setUp(self):
        TestHelper.setUp(self)
        opts = rocksdb.Options(create_if_missing=True, prefix_extractor=4)
        self.db = rocksdb.DB(os.path.join(self.db_loc, 'test'), opts)

    def _fill_db(self):
        for x in range(3000):
            keyx = b'%05x.%b' % (x, b'x')
            keyy = b'%05x.%b' % (x, b'y')
            keyz = b'%05x.%b' % (x, b'z')
            self.db.put(keyx, b'x')
            self.db.put(keyy, b'y')
            self.db.put(keyz, b'z')

    def test_prefix_iterkeys(self):
        self._fill_db()
        self.assertEqual(b'x', self.db.get(b'00001.x'))
        self.assertEqual(b'y', self.db.get(b'00001.y'))
        self.assertEqual(b'z', self.db.get(b'00001.z'))

        it = self.db.iterkeys()
        it.seek(b'00002')

        ref = [b'00002.x', b'00002.y', b'00002.z']
        ret = takewhile(lambda key: key.startswith(b'00002'), it)
        self.assertEqual(ref, list(ret))

    def test_prefix_iteritems(self):
        self._fill_db()

        it = self.db.iteritems()
        it.seek(b'00002')

        ref = {b'00002.z': b'z', b'00002.y': b'y', b'00002.x': b'x'}
        ret = takewhile(lambda item: item[0].startswith(b'00002'), it)
        self.assertEqual(ref, dict(ret))

class TestDBColumnFamilies(TestHelper):
    def setUp(self):
        TestHelper.setUp(self)
        opts = rocksdb.Options(create_if_missing=True)
        self.db = rocksdb.DB(
            os.path.join(self.db_loc, 'test'),
            opts,
        )

        self.cf_a = self.db.create_column_family(b'A', rocksdb.ColumnFamilyOptions())
        self.cf_b = self.db.create_column_family(b'B', rocksdb.ColumnFamilyOptions())

    def test_column_families(self):
        families = self.db.column_families
        names = [handle.name for handle in families]
        self.assertEqual([b'default', b'A', b'B'], names)
        for name in names:
            self.assertIn(self.db.get_column_family(name), families)

        self.assertEqual(
            names,
            rocksdb.list_column_families(
                os.path.join(self.db_loc, 'test'),
                rocksdb.Options(),
            )
        )

    def test_get_none(self):
        self.assertIsNone(self.db.get(b'k'))
        self.assertIsNone(self.db.get((self.cf_a, b'k')))
        self.assertIsNone(self.db.get((self.cf_b, b'k')))

    def test_put_get(self):
        key = (self.cf_a, b'k')
        self.db.put(key, b"v")
        self.assertEqual(b"v", self.db.get(key))
        self.assertIsNone(self.db.get(b"k"))
        self.assertIsNone(self.db.get((self.cf_b, b"k")))

    def test_multi_get(self):
        data = [
            (b'a', b'1default'),
            (b'b', b'2default'),
            (b'c', b'3default'),
            ((self.cf_a, b'a'), b'1a'),
            ((self.cf_a, b'b'), b'2a'),
            ((self.cf_a, b'c'), b'3a'),
            ((self.cf_b, b'a'), b'1b'),
            ((self.cf_b, b'b'), b'2b'),
            ((self.cf_b, b'c'), b'3b'),
        ]
        for value in data:
            self.db.put(*value)

        multi_get_lookup = [value[0] for value in data]

        ret = self.db.multi_get(multi_get_lookup)
        ref = {value[0]: value[1] for value in data}
        self.assertEqual(ref, ret)

    def test_delete(self):
        self.db.put((self.cf_a, b"a"), b"b")
        self.assertEqual(b"b", self.db.get((self.cf_a, b"a")))
        self.db.delete((self.cf_a, b"a"))
        self.assertIsNone(self.db.get((self.cf_a, b"a")))

    def test_write_batch(self):
        cfa = self.db.get_column_family(b"A")
        batch = rocksdb.WriteBatch()
        batch.put((cfa, b"key"), b"v1")
        batch.delete((self.cf_a, b"key"))
        batch.put((cfa, b"key"), b"v2")
        batch.put((cfa, b"key"), b"v3")
        batch.put((cfa, b"a"), b"1")
        batch.put((cfa, b"b"), b"2")

        self.db.write(batch)
        query = [(cfa, b"key"), (cfa, b"a"), (cfa, b"b")]
        ret = self.db.multi_get(query)

        self.assertEqual(b"v3", ret[query[0]])
        self.assertEqual(b"1", ret[query[1]])
        self.assertEqual(b"2", ret[query[2]])

    def test_key_may_exists(self):
        self.db.put((self.cf_a, b"a"), b'1')

        self.assertEqual(
            (False, None),
            self.db.key_may_exist((self.cf_a, b"x"))
        )
        self.assertEqual(
            (False, None),
            self.db.key_may_exist((self.cf_a, b'x'), fetch=True)
        )
        self.assertEqual(
            (True, None),
            self.db.key_may_exist((self.cf_a, b'a'))
        )
        self.assertEqual(
            (True, b'1'),
            self.db.key_may_exist((self.cf_a, b'a'), fetch=True)
        )

    def test_iter_keys(self):
        for x in range(300):
            self.db.put((self.cf_a, int_to_bytes(x)), int_to_bytes(x))

        it = self.db.iterkeys(self.cf_a)
        self.assertEqual([], list(it))

        it.seek_to_last()
        self.assertEqual([(self.cf_a, b'99')], list(it))

        ref = sorted([(self.cf_a, int_to_bytes(x)) for x in range(300)])
        it.seek_to_first()
        self.assertEqual(ref, list(it))

        it.seek(b'90')
        ref = sorted([(self.cf_a, int_to_bytes(x)) for x in range(90, 100)])
        self.assertEqual(ref, list(it))

    def test_iter_values(self):
        for x in range(300):
            self.db.put((self.cf_b, int_to_bytes(x)), int_to_bytes(x * 1000))

        it = self.db.itervalues(self.cf_b)
        self.assertEqual([], list(it))

        it.seek_to_last()
        self.assertEqual([b'99000'], list(it))

        ref = sorted([int_to_bytes(x) for x in range(300)])
        ref = [int_to_bytes(int(x) * 1000) for x in ref]
        it.seek_to_first()
        self.assertEqual(ref, list(it))

        it.seek(b'90')
        ref = [int_to_bytes(x * 1000) for x in range(90, 100)]
        self.assertEqual(ref, list(it))

    def test_iter_items(self):
        for x in range(300):
            self.db.put((self.cf_b, int_to_bytes(x)), int_to_bytes(x * 1000))

        it = self.db.iteritems(self.cf_b)
        self.assertEqual([], list(it))

        it.seek_to_last()
        self.assertEqual([((self.cf_b, b'99'), b'99000')], list(it))

        ref = sorted([int_to_bytes(x) for x in range(300)])
        ref = [((self.cf_b, x), int_to_bytes(int(x) * 1000)) for x in ref]
        it.seek_to_first()
        self.assertEqual(ref, list(it))

        it.seek(b'90')
        ref = [((self.cf_b, int_to_bytes(x)), int_to_bytes(x * 1000)) for x in range(90, 100)]
        self.assertEqual(ref, list(it))

    def test_reverse_iter(self):
        for x in range(100):
            self.db.put((self.cf_a, int_to_bytes(x)), int_to_bytes(x * 1000))

        it = self.db.iteritems(self.cf_a)
        it.seek_to_last()

        ref = reversed(sorted([(self.cf_a, int_to_bytes(x)) for x in range(100)]))
        ref = [(x, int_to_bytes(int(x[1]) * 1000)) for x in ref]

        self.assertEqual(ref, list(reversed(it)))

    def test_snapshot(self):
        cfa = self.db.get_column_family(b'A')
        self.db.put((cfa, b"a"), b"1")
        self.db.put((cfa, b"b"), b"2")

        snapshot = self.db.snapshot()
        self.db.put((cfa, b"a"), b"2")
        self.db.delete((cfa, b"b"))

        it = self.db.iteritems(cfa)
        it.seek_to_first()
        self.assertEqual({(cfa, b'a'): b'2'}, dict(it))

        it = self.db.iteritems(cfa, snapshot=snapshot)
        it.seek_to_first()
        self.assertEqual({(cfa, b'a'): b'1', (cfa, b'b'): b'2'}, dict(it))

    def test_get_property(self):
        for x in range(300):
            x = int_to_bytes(x)
            self.db.put((self.cf_a, x), x)

        self.assertEqual(b"300",
                         self.db.get_property(b'rocksdb.estimate-num-keys',
                                              self.cf_a))
        self.assertIsNone(self.db.get_property(b'does not exsits',
                                               self.cf_a))

    def test_compact_range(self):
        for x in range(10000):
            x = int_to_bytes(x)
            self.db.put((self.cf_b, x), x)

        self.db.compact_range(column_family=self.cf_b)

    # --- multi-column-family iterators ------------------------------------
    #
    # iterskeys/itersvalues/itersitems open one iterator per column family
    # (via NewIterators). Each CF gets the same keys but distinct values so a
    # wrong per-CF binding cannot hide behind matching data.

    def _fill_two_cfs(self):
        for k, v in ((b'1', b'a1'), (b'2', b'a2'), (b'3', b'a3')):
            self.db.put((self.cf_a, k), v)
        for k, v in ((b'1', b'b1'), (b'2', b'b2'), (b'3', b'b3')):
            self.db.put((self.cf_b, k), v)

    def test_iters_keys(self):
        self._fill_two_cfs()

        its = self.db.iterskeys([self.cf_a, self.cf_b])
        self.assertEqual(2, len(its))
        it_a, it_b = its
        it_a.seek_to_first()
        it_b.seek_to_first()
        keys_a = list(it_a)
        keys_b = list(it_b)

        self.assertEqual(
            [(self.cf_a, b'1'), (self.cf_a, b'2'), (self.cf_a, b'3')], keys_a)
        self.assertEqual(
            [(self.cf_b, b'1'), (self.cf_b, b'2'), (self.cf_b, b'3')], keys_b)

        # A keys iterator yields (handle, key) 2-tuples whose second element is
        # the raw key bytes. (When iterskeys was shadowed by a mis-named items
        # iterator it yielded ((handle, key), value) instead, so element [1]
        # was the inner tuple rather than bytes.)
        first = keys_a[0]
        self.assertIsInstance(first, tuple)
        self.assertEqual(2, len(first))
        self.assertEqual(self.cf_a, first[0])
        self.assertIsInstance(first[1], bytes)

    def test_iters_values(self):
        self._fill_two_cfs()

        its = self.db.itersvalues([self.cf_a, self.cf_b])
        self.assertEqual(2, len(its))
        it_a, it_b = its
        it_a.seek_to_first()
        it_b.seek_to_first()
        # A values iterator yields bare value bytes (no column-family handle).
        self.assertEqual([b'a1', b'a2', b'a3'], list(it_a))
        self.assertEqual([b'b1', b'b2', b'b3'], list(it_b))

    def test_iters_items(self):
        self._fill_two_cfs()

        # itersitems did not exist before the iterskeys/itersitems fix; calling
        # it raised AttributeError.
        its = self.db.itersitems([self.cf_a, self.cf_b])
        self.assertEqual(2, len(its))
        it_a, it_b = its
        it_a.seek_to_first()
        it_b.seek_to_first()
        self.assertEqual(
            [((self.cf_a, b'1'), b'a1'),
             ((self.cf_a, b'2'), b'a2'),
             ((self.cf_a, b'3'), b'a3')],
            list(it_a))
        self.assertEqual(
            [((self.cf_b, b'1'), b'b1'),
             ((self.cf_b, b'2'), b'b2'),
             ((self.cf_b, b'3'), b'b3')],
            list(it_b))

    # --- drop_column_family ------------------------------------------------

    def test_drop_column_family(self):
        self.db.put((self.cf_b, b'k'), b'v')
        self.assertEqual(b'v', self.db.get((self.cf_b, b'k')))
        self.assertTrue(self.cf_b.is_valid)

        self.db.drop_column_family(self.cf_b)

        # The handle is invalidated and removed from the live listing.
        self.assertFalse(self.cf_b.is_valid)
        names = [h.name for h in self.db.column_families]
        self.assertEqual([b'default', b'A'], names)

        # Using the dropped handle raises -- the Python weakref guard in
        # get_handle() fires before any RocksDB call.
        self.assertRaises(ValueError, self.db.put, (self.cf_b, b'x'), b'y')
        self.assertRaises(ValueError, self.db.get, (self.cf_b, b'k'))

    # --- per-column-family metadata ---------------------------------------

    def test_column_family_meta_data(self):
        for x in range(10000):
            x = int_to_bytes(x)
            self.db.put((self.cf_a, x), x)
        self.db.compact_range(column_family=self.cf_a)

        meta = self.db.get_column_family_meta_data(self.cf_a)
        self.assertEqual({'size', 'file_count'}, set(meta.keys()))
        self.assertIsInstance(meta['size'], int)
        self.assertGreater(meta['size'], 0)
        self.assertIsInstance(meta['file_count'], int)
        self.assertGreaterEqual(meta['file_count'], 1)

